`ICMg.randominit` <-
function() {
  .C("ICMgRandominit", PACKAGE="ICMg.iterations")
}

